package co2123.streetfood.controller;

import co2123.streetfood.StreetfoodApplication;
import co2123.streetfood.model.*;
import co2123.streetfood.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
public class AddEditController {

    @Autowired
    private VendorRepository vendorRepository;

    @Autowired
    private PhotoRepository photoRepository;

    @Autowired
    private AwardRepository awardRepository;

    @RequestMapping("editVendor")
    public String editVendorForm(@RequestParam Integer id, Model model) {
        Vendor foundVendor = vendorRepository.findById(id).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        model.addAttribute("vendor", foundVendor);
        return "forms/editVendor";
    }

    @RequestMapping("editedVendor")
    public String submittedEditForm(@RequestParam Integer id, @ModelAttribute Vendor vendor, Model model) {
        Vendor foundVendor = vendorRepository.findById(id).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        foundVendor.setName(vendor.getName());
        foundVendor.setLocation(vendor.getLocation());
        foundVendor.setCuisineType(vendor.getCuisineType());
        vendorRepository.save(foundVendor);

        return "redirect:/vendor?id=" + id;
    }

    @RequestMapping("editedVendorProfile")
    public String submittedProfileEditForm(@RequestParam Integer id, @ModelAttribute VendorProfile profile, Model model) {
        Vendor foundVendor = vendorRepository.findById(id).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        if (foundVendor.getProfile() == null) {
            foundVendor.setProfile(profile);
        } else {
            foundVendor.getProfile().setBio(profile.getBio());
            foundVendor.getProfile().setSocialMediaHandle(profile.getSocialMediaHandle());
            foundVendor.getProfile().setWebsite(profile.getWebsite());
        }

        vendorRepository.save(foundVendor);
        return "redirect:/vendor?id=" + id;
    }


    @RequestMapping("newDish")
    public String newDishForm(@RequestParam Integer id, Model model) {
        Vendor foundVendor = vendorRepository.findById(id).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        model.addAttribute("vendor", foundVendor);
        model.addAttribute("dish", new Dish());
        model.addAttribute("tags", StreetfoodApplication.tagList);
        return "forms/newDish";
    }

    @RequestMapping("addDish")
    public String addDish(@RequestParam Integer vendorid, @RequestParam List<Integer> tagIds, @ModelAttribute Dish dish, Model model) {
        Vendor foundVendor = vendorRepository.findById(vendorid).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        if (foundVendor.getDishes() == null) {
            foundVendor.setDishes(new ArrayList<>());
        }

        dish.setTags(new ArrayList<>());
        for (Integer tagId : tagIds) {
            dish.getTags().add(StreetfoodApplication.tagList.get(tagId - 1));
        }

        dish.setReviews(new ArrayList<>());
        dish.setVendor(foundVendor);
        foundVendor.getDishes().add(dish);

        vendorRepository.save(foundVendor); // saves dish automatically via cascade

        return "redirect:/vendor?id=" + vendorid;
    }


    @RequestMapping("newReview")
    public String newReview(@RequestParam Integer vendorid, @RequestParam Integer dishid, Model model) {
        Vendor foundVendor = vendorRepository.findById(vendorid).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        model.addAttribute("vendor", foundVendor);
        model.addAttribute("dishid", dishid);
        model.addAttribute("review", new Review());
        return "forms/newReview";
    }

    @RequestMapping("addReview")
    public String addReview(@RequestParam Integer vendorid, @RequestParam Integer dishid, @ModelAttribute Review review, Model model) {
        Vendor foundVendor = vendorRepository.findById(vendorid).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        Dish foundDish = foundVendor.getDishes().stream()
                .filter(d -> d.getId().equals(dishid))
                .findFirst().orElse(null);

        if (foundDish == null) return "redirect:/admin";

        if (foundDish.getReviews() == null) {
            foundDish.setReviews(new ArrayList<>());
        }

        review.setReviewDate(LocalDateTime.now());
        review.setDish(foundDish);
        foundDish.getReviews().add(review);

        vendorRepository.save(foundVendor); // saves review via cascade

        return "redirect:/vendor?id=" + vendorid;
    }


    @RequestMapping("newPhoto")
    public String newPhoto(@RequestParam Integer vendorId, Model model) {
        Vendor vendor = vendorRepository.findById(vendorId).orElse(null);
        if (vendor == null) return "redirect:/admin";

        model.addAttribute("vendor", vendor);
        model.addAttribute("photo", new Photo());
        return "forms/newPhoto";
    }

    @RequestMapping("addPhoto")
    public String addPhoto(@RequestParam Integer vendorId, @ModelAttribute Photo photo, Model model) {
        Vendor vendor = vendorRepository.findById(vendorId).orElse(null);
        if (vendor == null) return "redirect:/admin";

        if (vendor.getPhotos() == null) vendor.setPhotos(new ArrayList<>());
        photo.setVendor(vendor);
        vendor.getPhotos().add(photo);

        photoRepository.save(photo);
        vendorRepository.save(vendor);

        return "redirect:/vendor?id=" + vendorId;
    }


    @RequestMapping("newAward")
    public String newAward(@RequestParam Integer vendorId, Model model) {
        Vendor vendor = vendorRepository.findById(vendorId).orElse(null);
        if (vendor == null) return "redirect:/admin";

        model.addAttribute("vendor", vendor);
        model.addAttribute("award", new Award());
        return "forms/newAward";
    }

    @RequestMapping("addAward")
    public String addAward(@RequestParam Integer vendorId, @ModelAttribute Award award, Model model) {
        Vendor vendor = vendorRepository.findById(vendorId).orElse(null);
        if (vendor == null) return "redirect:/admin";

        if (vendor.getAwards() == null) vendor.setAwards(new ArrayList<>());
        award.setVendor(vendor);
        vendor.getAwards().add(award);

        awardRepository.save(award);
        vendorRepository.save(vendor);

        return "redirect:/vendor?id=" + vendorId;
    }

    @RequestMapping("editDish")
    public String editDishForm(@RequestParam Integer vendorid, @RequestParam Integer dishid, Model model) {
        Vendor foundVendor = vendorRepository.findById(vendorid).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        Dish foundDish = foundVendor.getDishes().stream()
                .filter(d -> d.getId().equals(dishid))
                .findFirst().orElse(null);

        if (foundDish == null) return "redirect:/admin";

        model.addAttribute("vendor", foundVendor);
        model.addAttribute("dish", foundDish);
        model.addAttribute("tags", StreetfoodApplication.tagList);
        return "forms/editDish";
    }

    @RequestMapping("editedDish")
    public String submittedEditDishForm(@RequestParam Integer vendorid, @RequestParam Integer dishid,
                                        @RequestParam(required = false) List<Integer> tagIds,
                                        @ModelAttribute Dish dish, Model model) {
        Vendor foundVendor = vendorRepository.findById(vendorid).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        Dish foundDish = foundVendor.getDishes().stream()
                .filter(d -> d.getId() == dishid)
                .findFirst().orElse(null);

        if (foundDish == null) return "redirect:/admin";

        foundDish.setName(dish.getName());
        foundDish.setPrice(dish.getPrice());
        foundDish.setDescription(dish.getDescription());
        foundDish.setSpiceLevel(dish.getSpiceLevel());

        if (foundDish.getTags() == null) foundDish.setTags(new ArrayList<>());
        else foundDish.getTags().clear();

        if (tagIds != null) {
            for (Integer tagId : tagIds) {
                foundDish.getTags().add(StreetfoodApplication.tagList.get(tagId - 1));
            }
        }

        vendorRepository.save(foundVendor);

        return "redirect:/vendor?id=" + vendorid;
    }

    @RequestMapping("editReview")
    public String editReview(@RequestParam Integer vendorId, @RequestParam Integer reviewId, Model model) {
        Vendor foundVendor = vendorRepository.findById(vendorId).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        Review foundReview = foundVendor.getDishes().stream()
                .flatMap(d -> d.getReviews().stream())
                .filter(r -> r.getId().equals(reviewId))
                .findFirst().orElse(null);

        if (foundReview == null) return "redirect:/admin";

        model.addAttribute("vendor", foundVendor);
        model.addAttribute("review", foundReview);
        return "forms/editReview";
    }

    @RequestMapping("editedReview")
    public String editedReview(@RequestParam Integer vendorId, @RequestParam Integer reviewId,
                               @ModelAttribute Review review, Model model) {
        Vendor foundVendor = vendorRepository.findById(vendorId).orElse(null);
        if (foundVendor == null) return "redirect:/admin";

        Review foundReview = foundVendor.getDishes().stream()
                .flatMap(d -> d.getReviews().stream())
                .filter(r -> r.getId().equals(reviewId))
                .findFirst().orElse(null);

        if (foundReview == null) return "redirect:/admin";

        foundReview.setReviewerName(review.getReviewerName());
        foundReview.setComment(review.getComment());
        foundReview.setRating(review.getRating());

        vendorRepository.save(foundVendor);

        return "redirect:/vendor?id=" + vendorId;
    }

    @RequestMapping("editPhoto")
    public String editPhoto(@RequestParam Integer photoId, Model model) {
        Photo photo = photoRepository.findById(photoId).orElse(null);
        if (photo == null) return "redirect:/admin";

        model.addAttribute("photo", photo);
        return "forms/editPhoto";
    }

    @RequestMapping("editedPhoto")
    public String editedPhoto(@RequestParam Integer photoId, @ModelAttribute Photo updatedPhoto, Model model) {
        Photo photo = photoRepository.findById(photoId).orElse(null);
        if (photo == null) return "redirect:/admin";

        photo.setDescription(updatedPhoto.getDescription());
        photo.setUrl(updatedPhoto.getUrl());

        photoRepository.save(photo);

        Vendor vendor = photo.getVendor();
        return "redirect:/vendor?id=" + vendor.getId();
    }

    @RequestMapping("editAward")
    public String editAward(@RequestParam Integer awardId, Model model) {
        Award award = awardRepository.findById(awardId).orElse(null);
        if (award == null) return "redirect:/admin";

        model.addAttribute("award", award);
        return "forms/editAward";
    }

    @RequestMapping("editedAward")
    public String editedAward(@RequestParam Integer awardId, @ModelAttribute Award updatedAward, Model model) {
        Award award = awardRepository.findById(awardId).orElse(null);
        if (award == null) return "redirect:/admin";

        award.setTitle(updatedAward.getTitle());
        award.setYear(updatedAward.getYear());

        awardRepository.save(award);

        Vendor vendor = award.getVendor();
        return "redirect:/vendor?id=" + vendor.getId();
    }
}
