package co2123.streetfood.repository;

import co2123.streetfood.model.Award;
import org.springframework.data.repository.CrudRepository;

public interface AwardRepository extends CrudRepository<Award, Integer> {
}
